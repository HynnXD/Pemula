## Userbot
```
apt update && apt upgrade -y
```
```
git clone https://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@github.com/ricoogh/ubot
```
```
cd ubot && screen -S ubot
```
```
apt install ffmpeg -y
```
```
bash installnode.sh
```
```
apt install python3.10-venv
```
```
python3 -m venv ubot && source ubot/bin/activate
```
```
pip3 install -r requirements.txt
```
```
cp sample.env .env && nano .env
```
```
screen -S ubot
```
```
python3 -m PyroUbot
```
```
---------- Menghidupan jika ubot mati -------------
```
```
cd ubotalfnew && screen -S ubotalfnew
```
```
python3 -m venv venv && source venv/bin/activate
```
```
screen -S ubotalfnew
```
```
python3 -m PyroUbot
```
